package com.example.vip.ders;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;

public class fakulteler extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fakulteler);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



    }
    public  void button2_Click (View v2)
    {
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        switch (v2.getId()) {
            case R.id.btn_memarliqfak:
                setContentView(R.layout.memarliqfak);
                break;
            case R.id.btn_insaatfak:
                setContentView(R.layout.insaatfak);
                break;
            case R.id.btnsutesfak:
                setContentView(R.layout.sutesruffatifak);
                break;
            case R.id.btn_neqliyyatfak:
                setContentView(R.layout.neqliyyatfak);
                break;
            case R.id.btn_insaattexfak:
                setContentView(R.layout.insaattexnofak);
                break;
            case R.id.btn_tikintiiqtisfak:
                setContentView(R.layout.tikintiistisadfak);
                break;
            case R.id.btn_mit:
                setContentView(R.layout.mitfak);
                break;
            case R.id.btn_ecnebiteldekan:
                setContentView(R.layout.ecnebitehsildekan);
                break;
            case R.id.btn_ecnebihazirligfak:
                setContentView(R.layout.ecnebihazirliqfak);
                break;
            case R.id.btn_ixtisasartfak:
                setContentView(R.layout.ixtisasartirmafak);
                break;
            case R.id.btn_sabahqurp:
                setContentView(R.layout.sabahqurup);
                break;
        }

    }
    @Override
    public void onBackPressed() {

        finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);


        // super.onBackPressed();




    }



    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home)
        {
            finish();
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

