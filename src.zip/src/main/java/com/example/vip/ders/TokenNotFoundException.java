package com.example.vip.ders;

/**
 * Created by VIP on 6/22/2017.
 */
public class TokenNotFoundException extends Exception {
    public TokenNotFoundException() {
        super();
    }
}