package com.example.vip.ders;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/**
 * Created by VIP on 6/9/2017.
 */

public class FcmMessagingService extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if(remoteMessage.getData().size()>0)
        {
            String title,message,img_url;
            title= remoteMessage.getData().get("title");
            message = remoteMessage.getData().get("message");
            img_url = remoteMessage.getData().get("img_url");

            Intent intent =new Intent(this,MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent =  PendingIntent.getActivity(this,0, intent,PendingIntent.FLAG_ONE_SHOT);
            NotificationCompat.Builder builder  = new NotificationCompat.Builder(this);
            builder.setContentTitle(title);
            builder.setContentText(remoteMessage.getNotification().getBody());
            builder.setSmallIcon(R.mipmap.azmiu_logo);
            builder.setContentIntent(pendingIntent);
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0, builder.build());

        }

    }
}
