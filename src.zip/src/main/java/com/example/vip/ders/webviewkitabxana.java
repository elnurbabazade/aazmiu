package com.example.vip.ders;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class webviewkitabxana extends AppCompatActivity {
    private WebView wv1;

    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home)
        {
            kabinet("http://library.azmiu.edu.az/");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
        kabinet("http://library.azmiu.edu.az/");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
    public  void kabinet(String pagename)
    {
        wv1=(WebView)findViewById(R.id.webview);
        wv1.setWebViewClient(new MainActivity.MyBrowser());

        wv1.loadUrl(pagename);

        wv1.getSettings().setLoadsImagesAutomatically(true);
        wv1.getSettings().setLoadWithOverviewMode(true);
      wv1.getSettings().setMinimumFontSize(28);
         wv1.setInitialScale(100);
        wv1.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
        //  wv1.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        wv1.getSettings().setUseWideViewPort(true);
        wv1.getSettings().setJavaScriptEnabled(true);
        wv1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    }


}

