package com.example.vip.ders;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;

public class tehsil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tehsil);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



    }

    @Override
    public void onBackPressed() {

        finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);


        // super.onBackPressed();




    }

    public void button3_Click(View v) {

        switch (v.getId()) {
            case R.id.btn_bakalavr:
                setContentView(R.layout.bakalavr);
                break;
            case R.id.btn_magistatur:
                setContentView(R.layout.magistratura);
                break;
            case R.id.btn_doktorantura:
                setContentView(R.layout.doktorantura);
                break;
            case R.id.btn_elavetehsil:
                setContentView(R.layout.elavetehsil);
                break;

            case R.id.btn_qebulkomisya:
                setContentView(R.layout.qebulkomisiyasi);
                break;
        }
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home)
        {
            finish();
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

