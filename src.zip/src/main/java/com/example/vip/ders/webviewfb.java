package com.example.vip.ders;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class webviewfb extends AppCompatActivity {
    private WebView wv1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
        wv1=(WebView)findViewById(R.id.webview);
        wv1.setWebViewClient(new MainActivity.MyBrowser());

       wv1.loadUrl("https://www.facebook.com/azerbaycan.memarliq.inshaat.universiteti");

        wv1.getSettings().setLoadsImagesAutomatically(true);
        wv1.getSettings().setJavaScriptEnabled(true);
        wv1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //  final Handler mHandler = new Handler();

    }

    public class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }


}

