package com.example.vip.ders;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    public Button btn_umiversitet;
    public Button btn_fakulteler;
    public Button btn_tehsil;
    public Button btn_tedris;
    public Button btn_sinaq;
    public Button btn_ictimaiheyat;
    public Button btn_kitabxanaa;
    public Button btn_elaqe;
    public RelativeLayout asagisetr;
    public Button btn_internetbagyoxla;
 //   public TableRow tablerow1;
 private WebView wv1;
    private FirebaseAuth firebaseAuth;
    public Handler mHandler = new Handler();

        @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.azmiu_home2);

          getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            asagisetr=(RelativeLayout) findViewById(R.id.asagisetr);
            btn_umiversitet = (Button) findViewById(R.id.btn_universitet);
            btn_tehsil = (Button) findViewById(R.id.btn_tehsil);
            btn_tedris = (Button) findViewById(R.id.btn_tedris);
            btn_sinaq = (Button) findViewById(R.id.btn_sinaq);
            btn_ictimaiheyat = (Button) findViewById(R.id.btn_ictimaiheyat);
            btn_kitabxanaa = (Button) findViewById(R.id.btn_kitabxanaa);
            btn_elaqe = (Button) findViewById(R.id.btn_elaqe);
            btn_fakulteler = (Button) findViewById(R.id.btn_fakulteler);
            btn_internetbagyoxla=(Button)findViewById(R.id.btn_intbagyoxla);
            //  tablerow1 = (TableRow) findViewById(R.id.tablerow1);
            firebaseAuth = FirebaseAuth.getInstance();



          if(isNetworkConnected()) {
              btn_internetbagyoxla.setVisibility(View.GONE);
              AdView adView = (AdView) this.findViewById(R.id.adView_bannerad);
              AdRequest adRequest = new AdRequest.Builder().build();
              adView.loadAd(adRequest);
              kabinet("http://student.azmiu.eu/istifadechi/giris");
          }
        }
    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null;
    }
    public  void kabinet(String pagename)
    {
        wv1=(WebView)findViewById(R.id.webvievkabinet);
        wv1.setWebViewClient(new MainActivity.MyBrowser());

        wv1.loadUrl(pagename);

        wv1.getSettings().setLoadsImagesAutomatically(true);
        wv1.getSettings().setLoadWithOverviewMode(true);
        wv1.getSettings().setMinimumFontSize(28);
          wv1.setInitialScale(100);
        wv1.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
        //  wv1.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        wv1.getSettings().setUseWideViewPort(true);
        wv1.getSettings().setJavaScriptEnabled(true);
        wv1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);


    }
    public static class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);

        setContentView(R.layout.azmiu_home2);
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    public void button1_Click(View v1) throws InterruptedException {

        animation();


        switch (v1.getId()) {
            case R.id.btn_universitet:
                animation();
                Intent i3 =new Intent(MainActivity.this,universitetjs.class);
                startActivity(i3);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_fakulteler:
                animation();
                Intent i6 =new Intent(MainActivity.this,fakulteler.class);
                startActivity(i6);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_tehsil:
                animation();
                Intent i4 =new Intent(MainActivity.this,tehsil.class);
                startActivity(i4);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_tedris:
                animation();
                Intent i5 =new Intent(MainActivity.this,tedris.class);
                startActivity(i5);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_sinaq:
                animation();
                        Intent i =new Intent(MainActivity.this,sinaq.class);
                        startActivity(i);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_ictimaiheyat:
                animation();
                Intent i7 =new Intent(MainActivity.this,ictimaheyat.class);
                startActivity(i7);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_kitabxanaa:
                animation();
                        Intent i1 =new Intent(MainActivity.this,webviewkitabxana.class);
                        startActivity(i1);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_elaqe:
                animation();
                Intent i8 =new Intent(MainActivity.this,elaqe.class);
                startActivity(i8);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;
            case R.id.btn_fb:
                animation();
                        Intent i2 =new Intent(MainActivity.this,webviewfb.class);
                        startActivity(i2);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                break;

        }
    }

   public void eslindebutton1clickdi(View v1) throws InterruptedException {
//
//
//
//
//                switch (v1.getId()) {
//                    case R.id.btn_universitet:
//                        window_open();
//                       this.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                               setContentView(R.layout.layout_universitet);
//                            }
//                        },500);
//                        break;
//                    case R.id.btn_fakulteler:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                        setContentView(R.layout.fakulteler);
//                            }
//                        },500);
//                        break;
//                    case R.id.btn_tehsil:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                setContentView(R.layout.tehsil);
//                            }
//                        },500);
//                        break;
//                    case R.id.btn_tedris:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                setContentView(R.layout.tedris);
//                            }
//                        },500);
//                        break;
//                    case R.id.btn_kabinet:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                Intent i =new Intent(MainActivity.this,sinaq.class);
//
//                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//                                startActivity(i);
//                            }
//                        },500);
//                        break;
//                    case R.id.btn_ictimaiheyat:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                setContentView(R.layout.ictimaiheyat);
//                            }
//                        },500);
//                        break;
//                    case R.id.btn_kitabxanaa:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                Intent i =new Intent(MainActivity.this,webviewkitabxana.class);
//
//                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//                                startActivity(i);
//                            }
//                        },500);
//                        break;
//
//                    case R.id.btn_elaqe:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run()  {
//                                setContentView(R.layout.elaqe);
//                            }
//                        },500);
//                        break;
//                    case R.id.btn_fb:
//                        window_open();
//                        mHandler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                Intent i =new Intent(MainActivity.this,webview.class);
//
//                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//                                startActivity(i);
//                            }
//                        },500);
//                        break;
//
//                }
  }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.action_profildencix:
                firebaseAuth.signOut();
                finish();

                startActivity(new Intent(this, LoginActivity_giris.class));
                return true;
            case R.id.action_bagla:
                finish();
                finish();
                System.exit(0);
                System.exit(0);
                return true;
            case android.R.id.home:
                setContentView(R.layout.azmiu_home2);
                if(isNetworkConnected())
                {
                    AdView adView = (AdView) this.findViewById(R.id.adView_bannerad);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                    btn_internetbagyoxla.setVisibility(View.GONE);
                    kabinet("http://student.azmiu.eu/istifadechi/giris");

                }





    }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Action Bar içinde kullanılacak menü öğelerini inflate edelim
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_activity_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }
         public void animation() {
//
//        Animation animation_left = new TranslateAnimation(0, 600, 0, 0);
//        animation_left.setDuration(250);
//        Animation animation_right = new TranslateAnimation(0, -600, 0, 0);
//        animation_right.setDuration(250);
//        Animation animation_top = new TranslateAnimation(0, 0, 0, -600);
//        animation_top.setDuration(250);
//
//             Animation fadeOut = new AlphaAnimation(1, 0);
//
//
//             fadeOut.setDuration(100);
//        tablerow1.startAnimation(fadeOut);
//        btn_umiversitet.startAnimation(fadeOut);
//        btn_tehsil.startAnimation(fadeOut);
//        btn_fakulteler.startAnimation(fadeOut);
//        btn_kitabxanaa.startAnimation(fadeOut);
//
//        asagisetr.startAnimation(fadeOut);
//        btn_kabinet.startAnimation(fadeOut);
//        btn_tedris.startAnimation(fadeOut);
//        btn_ictimaiheyat.startAnimation(fadeOut);
//        btn_elaqe.startAnimation(fadeOut);
//




            }

        }

